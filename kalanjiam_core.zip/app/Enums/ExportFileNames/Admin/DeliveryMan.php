<?php

namespace App\Enums\ExportFileNames\Admin;

enum DeliveryMan
{
    const EXPORT_XLSX = 'Delivery-Man-List.xlsx';
    const EXPORT_EARNING_LIST_XLSX = "Delivery-Man-Earnings-List.xlsx";
    const EXPORT_ORDER_LIST_XLSX = "Delivery-Man-Order-List.xlsx";
}
