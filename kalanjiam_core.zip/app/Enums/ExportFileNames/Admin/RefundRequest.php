<?php

namespace App\Enums\ExportFileNames\Admin;

enum RefundRequest
{
    const EXPORT_XLSX = 'refund-request.xlsx';
}
