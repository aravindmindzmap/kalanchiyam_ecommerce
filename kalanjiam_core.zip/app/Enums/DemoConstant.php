<?php
namespace App\Enums;

enum DemoConstant{
    const ADMIN = [
        'email' => 'admin@admin.com',
        'password' => '12345678'
    ];
    const VENDOR = [
        'email' => 'test.seller@gmail.com',
        'password' => '12345678'
    ];
}
