<?php

namespace App\Enums\ViewPaths\Admin;

enum SoftwareUpdate
{
    const VIEW = [
        URI => 'software-update',
        VIEW => 'admin-views.system-setup.software-update'
    ];

}
