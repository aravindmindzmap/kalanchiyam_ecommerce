<?php

namespace App\Enums\ViewPaths\Web;

enum Auth
{
    const CUSTOMER_LOGIN = 'admin-views.auth.login';
}
