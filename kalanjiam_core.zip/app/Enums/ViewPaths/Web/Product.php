<?php

namespace App\Enums\ViewPaths\Web;

enum Product
{
    const DETAILS = 'admin-views.product.add-new';
}
