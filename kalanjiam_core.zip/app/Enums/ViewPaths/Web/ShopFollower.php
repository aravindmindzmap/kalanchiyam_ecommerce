<?php

namespace App\Enums\ViewPaths\Web;

enum ShopFollower
{
    const SHOP_FOLLOW = [
      URI => 'shop-follow',
    ];
}
