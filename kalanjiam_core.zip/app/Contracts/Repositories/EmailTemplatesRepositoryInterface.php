<?php

namespace App\Contracts\Repositories;

interface EmailTemplatesRepositoryInterface extends RepositoryInterface
{

}
