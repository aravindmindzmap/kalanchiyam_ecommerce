<?php

namespace App\Contracts\Repositories;

interface EmergencyContactRepositoryInterface extends RepositoryInterface
{

}
