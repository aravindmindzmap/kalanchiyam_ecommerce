<?php

namespace App\Contracts\Repositories;

interface NotificationSeenRepositoryInterface extends RepositoryInterface
{

}
