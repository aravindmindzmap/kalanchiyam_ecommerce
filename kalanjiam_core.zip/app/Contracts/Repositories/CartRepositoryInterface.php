<?php

namespace App\Contracts\Repositories;

interface CartRepositoryInterface extends RepositoryInterface
{

}
