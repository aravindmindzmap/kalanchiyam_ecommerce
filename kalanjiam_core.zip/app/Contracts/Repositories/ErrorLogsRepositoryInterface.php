<?php

namespace App\Contracts\Repositories;

interface ErrorLogsRepositoryInterface extends RepositoryInterface
{

}
