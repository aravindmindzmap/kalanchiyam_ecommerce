<?php

namespace App\Contracts\Repositories;

interface OrderExpectedDeliveryHistoryRepositoryInterface extends RepositoryInterface
{

}
