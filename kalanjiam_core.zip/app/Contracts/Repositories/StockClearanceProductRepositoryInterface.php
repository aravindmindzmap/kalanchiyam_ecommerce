<?php

namespace App\Contracts\Repositories;

interface StockClearanceProductRepositoryInterface extends RepositoryInterface
{

}
