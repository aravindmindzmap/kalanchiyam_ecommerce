<?php

namespace App\Contracts\Repositories;

interface PasswordResetRepositoryInterface extends RepositoryInterface
{

}
