<?php

namespace App\Contracts\Repositories;

interface RestockProductCustomerRepositoryInterface extends RepositoryInterface
{

}
