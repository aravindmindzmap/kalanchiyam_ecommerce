<?php

namespace App\Contracts\Repositories;

interface CustomerWalletRepositoryInterface extends RepositoryInterface
{

}
