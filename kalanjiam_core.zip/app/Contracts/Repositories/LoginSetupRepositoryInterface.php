<?php

namespace App\Contracts\Repositories;

interface LoginSetupRepositoryInterface extends RepositoryInterface
{

}
