<?php

namespace App\Contracts\Repositories;

interface ColorRepositoryInterface extends RepositoryInterface
{

}
