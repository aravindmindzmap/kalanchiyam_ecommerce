<?php

namespace App\Contracts\Repositories;

interface VendorRegistrationReasonInterface extends RepositoryInterface
{

}
