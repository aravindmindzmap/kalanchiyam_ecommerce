<?php

namespace App\Contracts\Repositories;

interface DeliveryManTransactionRepositoryInterface extends RepositoryInterface
{

}
