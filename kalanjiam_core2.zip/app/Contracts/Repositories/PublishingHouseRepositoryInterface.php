<?php

namespace App\Contracts\Repositories;

interface PublishingHouseRepositoryInterface extends RepositoryInterface
{

}
