<?php

namespace App\Contracts\Repositories;

interface ShippingTypeRepositoryInterface extends RepositoryInterface
{

}
