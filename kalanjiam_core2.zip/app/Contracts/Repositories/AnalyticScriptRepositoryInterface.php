<?php

namespace App\Contracts\Repositories;

interface AnalyticScriptRepositoryInterface extends RepositoryInterface
{

}
