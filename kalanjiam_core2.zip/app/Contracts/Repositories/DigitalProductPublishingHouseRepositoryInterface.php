<?php

namespace App\Contracts\Repositories;

interface DigitalProductPublishingHouseRepositoryInterface extends RepositoryInterface
{

}
