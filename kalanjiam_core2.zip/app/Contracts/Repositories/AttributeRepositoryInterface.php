<?php

namespace App\Contracts\Repositories;

interface AttributeRepositoryInterface extends RepositoryInterface
{

}
