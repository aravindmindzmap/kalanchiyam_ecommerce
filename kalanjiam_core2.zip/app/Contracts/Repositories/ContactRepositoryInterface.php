<?php

namespace App\Contracts\Repositories;

interface ContactRepositoryInterface extends RepositoryInterface
{

}
