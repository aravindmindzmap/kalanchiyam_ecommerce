<?php

namespace App\Contracts\Repositories;

interface DigitalProductAuthorRepositoryInterface extends RepositoryInterface
{

}
