<?php

namespace App\Contracts\Repositories;

interface AddFundBonusCategoriesRepositoryInterface extends RepositoryInterface
{

}
