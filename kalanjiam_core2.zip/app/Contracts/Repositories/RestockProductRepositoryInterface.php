<?php

namespace App\Contracts\Repositories;

interface RestockProductRepositoryInterface extends RepositoryInterface
{

}
