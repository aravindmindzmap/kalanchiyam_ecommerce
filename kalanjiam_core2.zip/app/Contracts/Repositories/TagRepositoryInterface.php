<?php

namespace App\Contracts\Repositories;

interface TagRepositoryInterface extends RepositoryInterface
{
}
