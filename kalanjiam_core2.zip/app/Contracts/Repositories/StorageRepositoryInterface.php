<?php

namespace App\Contracts\Repositories;

interface StorageRepositoryInterface extends RepositoryInterface
{

}
