<?php

namespace App\Contracts\Repositories;

interface StockClearanceSetupRepositoryInterface extends RepositoryInterface
{

}
