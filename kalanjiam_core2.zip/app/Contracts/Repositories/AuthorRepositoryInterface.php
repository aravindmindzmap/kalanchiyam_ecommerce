<?php

namespace App\Contracts\Repositories;

interface AuthorRepositoryInterface extends RepositoryInterface
{

}
