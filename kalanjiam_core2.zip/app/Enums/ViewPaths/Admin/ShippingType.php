<?php

namespace App\Enums\ViewPaths\Admin;

enum ShippingType
{
    const INDEX = [
        URI => 'index',
        VIEW => ''
    ];
}
