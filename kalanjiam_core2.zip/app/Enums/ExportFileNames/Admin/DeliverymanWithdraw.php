<?php

namespace App\Enums\ExportFileNames\Admin;

enum DeliverymanWithdraw
{
    const EXPORT_XLSX = 'Delivery-Man-Withdraw-Request.xlsx';
}
