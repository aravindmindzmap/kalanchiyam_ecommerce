<?php

namespace App\Enums\ExportFileNames\Admin;

enum Coupon
{
    const EXPORT_XLSX = 'Coupon-list.xlsx';
}
